// MiniUartDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "afxcmn.h"

#include "Option.h"

class CMiniUartDlgAutoProxy;

#define ON_NEW_INSTANCE		WM_USER + 1
#define ON_FREE_INSTANCE	WM_USER + 2
#define	ON_COM_OPEN			WM_USER + 3	
#define	ON_COM_CLOSE		WM_USER + 4	


//typedef struct{
//    long Adc;
//    long Fre;
//    long Iadc;
//}Tab_t;
//typedef struct{
//  Tab_t Zero;
//  Tab_t Air;
//}Parameter_t;  //24�ֽ�


// CMiniUartDlg �Ի���
class CMiniUartDlg : public CDialog
{
	DECLARE_DYNAMIC(CMiniUartDlg);
	friend class CMiniUartDlgAutoProxy;

// ����
public:
	CMiniUartDlg(CWnd* pParent = NULL);	// ��׼���캯��
	virtual ~CMiniUartDlg();
// �Ի�������
	enum { IDD = IDD_MINIUART_DIALOG };

	Option m_OptionFrm;	//���ô���

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

public:
	void CreateStatusBar();
	CStatusBar m_Statusbar;
	//===========================================================================
	CnComm Comm_;
	int iInstance_;
	void ScanCom();
	void OpenCom();	
	afx_msg LRESULT OnReceive(WPARAM, LPARAM);
	CString	m_filepath;//�ļ�·��
	void PrepareIAP(void);
	void CommTimerIAP(void);
	void CommRxView(void);

	long TimeOut;
	//===========================================================================
	#ifdef USB_EN
	static DWORD WINAPI ReadReport(void*);
	static DWORD WINAPI WriteReport(void*);
	BOOL OnDeviceChange(UINT nEventType,DWORD dwData);	
	void GetDeviceCapabilities();
	void RefreshDevices();
	#endif
	BOOL OnDeviceChange(UINT nEventType,DWORD dwData);	
	//===========================================================================
// ʵ��
protected:
	CMiniUartDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	DECLARE_MESSAGE_MAP()
public:
	CProgressCtrl m_Progress;
	CComboBox m_ComList;
	CListBox m_DebugOut;
	afx_msg void OnBnClickedFileOpen();
	afx_msg void OnBnClickedDownLoad();
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnBnClickedSeting();
	//afx_msg void OnBnClickedButton4();
	//afx_msg void OnBnClickedButton5();
	//afx_msg void OnBnClickedButton6();
	//afx_msg void OnBnClickedButton8();
	//afx_msg void OnBnClickedButton7();
	CListCtrl m_FeNFeParaList;
	//CListCtrl m_UserFeNFeParaList;

	void ExcelTest(void);

	//void DisplayFeNFePara();
	void ListFeNFeParaInit();
	//afx_msg void OnBnClickedButton11();
	//afx_msg void OnBnClickedButton10();
	//CStatic m_Serial;
	CString m_Serial;
	//afx_msg void OnBnClickedButton9();
	//afx_msg void OnBnClickedButton12();
	//afx_msg void OnStnClickedStatic00();
	//CString mFeNFeInf;
	//CString mFeInf;
	//CString mNFeInf;
};
