#pragma once

#include "afxwin.h"
#include "Resource.h"
#include "afxcmn.h"

// Option �Ի���

class Option : public CDialog
{
	DECLARE_DYNAMIC(Option)

public:
	Option(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~Option();

// �Ի�������
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	void UpdataIniBuf();
	CString m_BINstart;
	CString m_BINstop;
	CString m_WriteStart;
	int gBinStar,gBinStop,gWriteStar; 
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnBnClickedButton1();
};
