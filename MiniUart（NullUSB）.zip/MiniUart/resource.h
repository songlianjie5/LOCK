//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MiniUart.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDD_MINIUART_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     131
#define IDC_LIST1                       1001
#define IDC_COMBO1                      1002
#define IDC_BUTTON1                     1003
#define IDC_BUTTON2                     1004
#define IDC_PROGRESS1                   1005
#define IDC_BUTTON3                     1007
#define IDC_EDIT1                       1010
#define IDC_EDIT2                       1011
#define IDC_EDIT3                       1012
#define IDC_BUTTON4                     1013
#define IDC_BUTTON5                     1014
#define IDC_STATIC_F                    1017
#define IDC_STATIC_A                    1017
#define IDC_STATIC11                    1018
#define IDC_STATIC22                    1019
#define IDC_STATIC33                    1020
#define IDC_STATIC44                    1021
#define IDC_STATIC55                    1022
#define IDC_STATIC66                    1023
#define IDC_BUTTON6                     1024
#define IDC_BUTTON7                     1025
#define IDC_BUTTON8                     1026
#define IDC_LIST2                       1029
#define IDC_BUTTON10                    1033
#define IDC_BUTTON11                    1034
#define IDC_STATIC77                    1036
#define IDC_STATIC88                    1037
#define IDC_STATIC99                    1038
#define IDC_STATIC00                    1039
#define IDC_STATICAA                    1040
#define IDC_STATICBB                    1041
#define IDC_STATICIII                   1043
#define IDC_STATICFe                    1044
#define IDC_STATICNFe                   1045
#define IDC_STATICIadc                  1046
#define IDC_BUTTON9                     1047
#define IDC_BUTTON12                    1048
#define IDC_STATIC_FE30_ADC             1049
#define IDC_STATIC_FE30_Iadc            1050
#define IDC_STATIC_FE30_Fre             1051
#define IDC_STATIC_FE30_AirIadc         1052
#define IDC_STATIC_FE30_AirFre          1053
#define IDC_STATIC_FE30_Tep             1054
#define IDC_STATIC_FE30_AirADC          1055
#define IDC_STATIC_FE10_ADC             1056
#define IDC_STATIC_FE10_Iadc            1057
#define IDC_STATIC_FE10_Fre             1058
#define IDC_STATIC_FE10_AirADC          1059
#define IDC_STATIC_FE10_AirIadc         1060
#define IDC_STATIC_FE10_AirFre          1061
#define IDC_STATIC_FE10_tep             1062
#define IDC_EDIT4                       1064

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1065
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
