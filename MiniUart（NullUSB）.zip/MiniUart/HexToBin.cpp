#include "StdAfx.h"  
#include "HexToBin.h"  
//--------------------------------------------
#define MAXLENTH 77 // 32 bytes valid record in a line
#define hexval(c) ((c) >= '0' && (c) <= '9' ? \
(c) - '0' : \
(c) >= 'A' && (c) <= 'F' ? \
(c) - 'A' + 10 : \
(c) >= 'a' && (c) <= 'f' ? \
(c) - 'a' + 10 : \
-1 )

char linebuff[MAXLENTH], *bufptr;
unsigned char getcode()// combine a byte and increase the pointer.
{
    unsigned char i;
    i = *bufptr++;
    i = i << 4;
    i |= *bufptr++;
    return i;
}
//--------------------------------------------
char ch, validline;
unsigned int Line = 0; // Program Counter , Source File line
unsigned char attrib, areclen, temp, checksum;
long base,offset; // file offset at writting
int ConvertHexToBin(const char *str,long int HexLen,HexToBinData *pData)  
{  
    ASSERT(str !=NULL);  
    ASSERT(pData !=NULL);  

    Line = 0;
	validline = 0;
    while (HexLen--)
    {
        ch = *str++;
        if (ch == ':')
            validline = 1; // A valid record must be started with :
        else if (ch == '\t')
        {
            validline = 0;
            Line++;			//����������1
        }
        else
            validline = 0; // Omit the comment

        if (validline)
        {
			memcpy(linebuff,str,MAXLENTH);//��ȡһ�е�����
			bufptr = linebuff;
            Line++;			
            // Do the Checksum--------------------------------------
            checksum = 0;
            temp = 1;
            do
            {
                *bufptr = hexval(*bufptr);
                temp++;
                if (temp % 2)
                    checksum += *bufptr + *(bufptr - 1) * 16;
            }
            while (*++bufptr != 0x0D);//�س�
            // checksum+=*(bufptr-1);--------------------------------
            if (checksum) //�����Ϊ0����ȷ
                return 2;

            bufptr = linebuff; //���»ص�linebuff��ʼ
            areclen = getcode(); // First 2 bytes are record length
            offset = getcode(); // Second 4 bytes are record offset
            offset = (offset & 0xff) << 8; // Avoid sign extension
            offset |= getcode();
            attrib = getcode(); 
            if (attrib==1)//����Ϊ1ʱ�������ǽ�����
            {
				return 0;
            }
			else if(attrib==4)//.����Ϊ4ʱ�����л���ַ
			{
				base = offset;
			}
			else if(attrib==5)
			{
				;
			}
			else //��ֻҪ����
			{
				for (temp = 0; temp < areclen; temp++)
				{
					pData->pContent[base+offset+temp] = getcode();
					if((base+offset+temp)>pData->len )pData->len = (base+offset+temp)+1;
				}
			}
        }
    }
	//-------------------------------------------
    return 0;  
}  