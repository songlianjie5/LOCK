// Option.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Option.h"

 #include <Shlwapi.h> #pragma comment(lib, "shlwapi.lib")

// Option �Ի���

IMPLEMENT_DYNAMIC(Option, CDialog)

Option::Option(CWnd* pParent /*=NULL*/)
	: CDialog(Option::IDD, pParent)
	, m_BINstart(_T(""))
	, m_BINstop(_T(""))
	, m_WriteStart(_T(""))
{

}

Option::~Option()
{
}

void Option::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_BINstart);
	DDX_Text(pDX, IDC_EDIT2, m_BINstop);
	DDX_Text(pDX, IDC_EDIT3, m_WriteStart);
}


BEGIN_MESSAGE_MAP(Option, CDialog)
	ON_BN_CLICKED(IDOK, &Option::OnBnClickedOk)
	ON_WM_CREATE()

	ON_BN_CLICKED(IDC_BUTTON1, &Option::OnBnClickedButton1)
END_MESSAGE_MAP()


// Option ��Ϣ��������

void Option::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
//----------------------------------------------------------------------------
	CString strSection       = "Section1";
	WritePrivateProfileString(strSection,"BinStart:",m_BINstart,".//Ini.ini");  //д��ini�ļ�����Ӧ�ֶ�
	WritePrivateProfileString(strSection,"BinStop:",m_BINstop,".//Ini.ini");
	WritePrivateProfileString(strSection,"WriteAdr:",m_WriteStart,".//Ini.ini");
//----------------------------------------------------------------------------
	char *str;
	str=m_BINstart.GetBuffer(m_BINstart.GetLength());
	StrToIntEx(str, STIF_SUPPORT_HEX, &gBinStar);
	str=m_BINstop.GetBuffer(m_BINstop.GetLength());
	StrToIntEx(str, STIF_SUPPORT_HEX, &gBinStop);
	str=m_WriteStart.GetBuffer(m_WriteStart.GetLength());
	StrToIntEx(str, STIF_SUPPORT_HEX, &gWriteStar);
//----------------------------------------------------------------------------
	OnOK();
}

int Option::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	// TODO:  �ڴ�������ר�õĴ�������
	//int BinStart = 0x0000;
	//int BinStop = 0x3C00;
	//int WriteStart = 0xC000;
	//m_BINstart.Format("0x%04X",BinStart);
	//m_BINstop.Format("0x%04X",BinStop);
	//m_WriteStart.Format("0x%04X",WriteStart);

	CString strSection       = "Section1";
	char strBuff[256];
	GetPrivateProfileString(strSection,"BinStart:",NULL,strBuff,80,".//Ini.ini"); //��ȡini�ļ�����Ӧ�ֶε�����
	m_BINstart = strBuff;
	GetPrivateProfileString(strSection,"BinStop:",NULL,strBuff,80,".//Ini.ini");
	m_BINstop = strBuff;
	GetPrivateProfileString(strSection,"WriteAdr:",NULL,strBuff,80,".//Ini.ini");
	m_WriteStart = strBuff;

//----------------------------------------------------------------------------
	char *str;
	str=m_BINstart.GetBuffer(m_BINstart.GetLength());
	StrToIntEx(str, STIF_SUPPORT_HEX, &gBinStar);
	str=m_BINstop.GetBuffer(m_BINstop.GetLength());
	StrToIntEx(str, STIF_SUPPORT_HEX, &gBinStop);
	str=m_WriteStart.GetBuffer(m_WriteStart.GetLength());
	StrToIntEx(str, STIF_SUPPORT_HEX, &gWriteStar);
//----------------------------------------------------------------------------
	return 0;
}
void Option::UpdataIniBuf()
{
	CString strSection       = "Section1";
	char strBuff[256];
	GetPrivateProfileString(strSection,"BinStart:",NULL,strBuff,80,".//Ini.ini"); //��ȡini�ļ�����Ӧ�ֶε�����
	m_BINstart = strBuff;
	GetPrivateProfileString(strSection,"BinStop:",NULL,strBuff,80,".//Ini.ini");
	m_BINstop = strBuff;
	GetPrivateProfileString(strSection,"WriteAdr:",NULL,strBuff,80,".//Ini.ini");
	m_WriteStart = strBuff;

//----------------------------------------------------------------------------
	char *str;
	str=m_BINstart.GetBuffer(m_BINstart.GetLength());
	StrToIntEx(str, STIF_SUPPORT_HEX, &gBinStar);
	str=m_BINstop.GetBuffer(m_BINstop.GetLength());
	StrToIntEx(str, STIF_SUPPORT_HEX, &gBinStop);
	str=m_WriteStart.GetBuffer(m_WriteStart.GetLength());
	StrToIntEx(str, STIF_SUPPORT_HEX, &gWriteStar);
}


void Option::OnBnClickedButton1()//����������
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//for(int i=0;i<40;i++)
	//{
	//	FreThinkTabNFe[i] = (Tat_t *)&InputReport[0+(0x0C*i)];
	//	AdcThinkTab[i] = (Tat_t *)&InputReport[0x200+(0x0C*i)];
	//}

	//��ʾ���б�
	UpdateData(false);
}
