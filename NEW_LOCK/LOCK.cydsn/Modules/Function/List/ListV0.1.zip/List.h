/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef _LIST_H
#define _LIST_H

#include "main.h"
    
typedef struct FunNode {
	void(*Fun)(void);
	char *Describe;
	uint16_t Tick;
	uint16_t Period;
	uint16_t RunCount;
	struct FunNode *Prev;
	struct FunNode *Next;
}FunNode_t;

#define BASE_TICK_MS TIME_BASIC_MS          //基本运行时间单位ms

extern bool RegisterCallback(FunNode_t *pList, void(*callback)(), char *descr, uint16_t TickCount, uint16_t TickTaget, uint16_t RunCount);
extern bool UnRegisterCallback(FunNode_t *pList, void(*callback)());
extern bool ListRun(FunNode_t *pList);
extern bool ListInit(void);
extern FunNode_t List;

#endif
/* [] END OF FILE */
